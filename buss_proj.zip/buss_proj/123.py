import sqlite3

# Подключение к базе
conn = sqlite3.connect('db.sqlite3')
cursor = conn.cursor()

# Вставка маршрута в таблицу
cursor.execute("""
    INSERT INTO admin_panel_route (
        from_city, to_city, departure_time, arrival_time, price, total_seats
    ) VALUES (?, ?, ?, ?, ?, ?)
""", (
    'Almaty', 'Shymkent',
    '2025-05-10 08:00:00', '2025-05-10 17:30:00',
    9000, 48
))

# Сохраняем изменения
conn.commit()
conn.close()

print("✅ Маршрут успешно добавлен.")
