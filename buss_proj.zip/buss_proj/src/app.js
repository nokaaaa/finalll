const express = require('express');
const bodyParser = require('body-parser');
const db = require('./database');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('templates'));

// Обработка покупки билета
// Обработка покупки билета
app.post('/purchase', (req, res) => {
  const { cardNumber, expiry, cvv } = req.body;

  const query = `
    INSERT INTO tickets (card_number, expiry_date, cvv, purchase_date)
    VALUES (?, ?, ?, datetime('now'))
  `;
  db.run(query, [cardNumber, expiry, cvv], function (err) {
    if (err) {
      console.error(err.message);
      return res.status(500).send('Ошибка при сохранении данных.');
    }

    // Сохранение купленного билета в "Мои билеты"
    const ticketQuery = `
      INSERT INTO my_tickets (ticket_name, purchase_date)
      VALUES (?, datetime('now'))
    `;
    db.run(ticketQuery, ['Билет №' + this.lastID], (err) => {
      if (err) {
        console.error(err.message);
        return res.status(500).send('Ошибка при сохранении билета.');
      }
      // Перенаправление на страницу "Мои билеты"
      res.redirect('/my-tickets');
    });
  });
});
app.post('/purchase', (req, res) => {
  const { cardNumber, expiry, cvv } = req.body;

  const query = `
    INSERT INTO tickets (card_number, expiry_date, cvv, purchase_date)
    VALUES (?, ?, ?, datetime('now'))
  `;
  db.run(query, [cardNumber, expiry, cvv], function (err) {
    if (err) {
      console.error(err.message);
      return res.status(500).send('Ошибка при сохранении данных.');
    }

    // Сохранение купленного билета в "Мои билеты"
    const ticketQuery = `
      INSERT INTO my_tickets (ticket_name, purchase_date)
      VALUES (?, datetime('now'))
    `;
    db.run(ticketQuery, ['Билет №' + this.lastID], (err) => {
      if (err) {
        console.error(err.message);
        return res.status(500).send('Ошибка при сохранении билета.');
      }
      res.redirect('/my-tickets');
    });
  });
});

// Отображение купленных билетов
app.get('/my-tickets', (req, res) => {
  const query = `SELECT * FROM my_tickets`;
  db.all(query, [], (err, rows) => {
    if (err) {
      console.error(err.message);
      return res.status(500).send('Ошибка при получении данных.');
    }

    let ticketsHtml = rows
      .map(
        (ticket) =>
          `<li>Название: ${ticket.ticket_name}, Дата покупки: ${ticket.purchase_date}</li>`
      )
      .join('');

    res.send(`
      <h1>Мои билеты</h1>
      <ul>${ticketsHtml}</ul>
      <a href="/payment.html">Назад к оплате</a>
    `);
  });
});

app.listen(3000, () => {
  console.log('Сервер запущен на http://localhost:3000');
});