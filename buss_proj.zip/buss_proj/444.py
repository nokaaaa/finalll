import sqlite3

conn = sqlite3.connect('db.sqlite3')
cursor = conn.cursor()

routes = [
    ('Astana', 'Almaty', '2025-05-12 07:00:00', '2025-05-12 19:00:00', 10000, 48),
    ('Karaganda', 'Shymkent', '2025-05-15 06:30:00', '2025-05-15 20:45:00', 12000, 50),
    ('Aktobe', 'Kostanay', '2025-05-18 08:00:00', '2025-05-18 16:00:00', 8000, 40),
    ('Uralsk', 'Atyrau', '2025-05-20 10:00:00', '2025-05-20 22:30:00', 9000, 45),
    ('Kyzylorda', 'Taraz', '2025-05-22 09:15:00', '2025-05-22 17:00:00', 7500, 42),
    ('Pavlodar', 'Semey', '2025-05-25 05:45:00', '2025-05-25 12:30:00', 6500, 46)
]

for route in routes:
    cursor.execute("""
        INSERT INTO admin_panel_route (
            from_city, to_city, departure_time, arrival_time, price, total_seats
        ) VALUES (?, ?, ?, ?, ?, ?)
    """, route)

conn.commit()
conn.close()

print("✅ Маршруты добавлены.")
