from django.urls import path
from django.contrib.auth import views as auth_views
from . import views
from django.views.generic import TemplateView
from .views import buy_seats
from .views import payment_view
from django.urls import path
from . import views
from .views import my_tickets_view, fake_payment_view

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('road/', views.road, name='road'),
    path('tickets/', views.tickets, name='tickets'),
    path('statistics/', views.statistics, name='statistics'),
    path('settings/', views.settings, name='settings'),
    path('route/<int:pk>/', views.RouteDetailView.as_view(), name='route_detail'),
    path('contact/', views.contact, name='contact'),
    path('login/', views.custom_login, name='login'),
    path('register/', views.register, name='register'),
    path('logout/', views.logout_view, name='logout'),
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),
    path('route/create/', views.create_route, name='create_route'),
    path('route/<int:route_id>/', views.route_detail, name='route_detail'),
    path('route/<int:route_id>/boarding-list/', views.generate_boarding_list, name='boarding_list'),
    path('route/<int:route_id>/book/', views.book_ticket, name='book_ticket'),
    path('ticket/<int:ticket_id>/purchase/', views.purchase_ticket, name='purchase_ticket'),
    path('ticket/<int:ticket_id>/refund/', views.refund_ticket, name='refund_ticket'),
    path('toggle-favorite/<int:route_id>/', views.toggle_favorite, name='toggle_favorite'),
    path('notifications/', views.get_notifications, name='get_notifications'),
    path('notifications/<int:notification_id>/read/', views.mark_notification_read, name='mark_notification_read'),
    path('profile/', views.profile, name='profile'),
        path('buy_seats/', buy_seats, name='buy_seats'),
        path("buy-tickets/", views.buy_tickets, name="buy_tickets"),
         path('fake-payment/', TemplateView.as_view(template_name='fake_payment.html'), name='fake_payment'),
         path('success/', TemplateView.as_view(template_name='payment_success.html'), name='payment_success'),
         path('payment/', payment_view, name='payment'),
    path('buy/<int:route_id>/<str:seat_number>/', views.buy_ticket, name='buy_ticket'),
    path('my-tickets/', views.my_tickets, name='my_tickets'),
    path('create-checkout-session/', views.create_checkout_session, name='create_checkout_session'),
    path('success/', views.success_view, name='success'),
    path('cancel/', views.cancel_view, name='cancel'),
    path('create-checkout-session/', views.create_checkout_session, name='create_checkout_session'),
path('success/', views.success_view, name='success'),
path('cancel/', views.cancel_view, name='cancel'),
path('create-checkout-session/', views.create_checkout_session, name='create_checkout_session'),
    path('create-checkout-session/', views.create_checkout_session, name='create_checkout_session'),
    path('success/', views.success_view, name='success'),
    path('cancel/', views.cancel_view, name='cancel'),
    path('my_tickets/', views.my_tickets, name='my_tickets'),
    path('my-tickets/', views.my_tickets_view, name='my_tickets'),
        path('my-tickets/', my_tickets_view, name='my_tickets'),
    path('fake-payment/', fake_payment_view, name='fake_payment'),



] 