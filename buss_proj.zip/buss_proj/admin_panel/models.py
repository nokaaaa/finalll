from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone

# Create your models here.
class Route(models.Model):
    # поля маршрута (начало, конец, дата/время и т.д.)
    total_seats = models.PositiveIntegerField(default=50, verbose_name="Всего мест")  # например
class Route(models.Model):
    
    STATUS_CHOICES = [
        ('scheduled', 'Запланирован'),
        ('on_route', 'В пути'),
        ('completed', 'Завершен'),
        ('cancelled', 'Отменен'),
    ]

    number = models.CharField(max_length=10, verbose_name="Номер маршрута", default='000')
    from_city = models.CharField(max_length=100, verbose_name="Откуда")
    to_city = models.CharField(max_length=100, verbose_name="Куда")
    departure_time = models.DateTimeField(verbose_name="Время отправления")
    arrival_time = models.DateTimeField(verbose_name="Время прибытия")
    price = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Цена")
    total_seats = models.IntegerField(verbose_name="Всего мест")
    available_seats = models.IntegerField(verbose_name="Доступно мест")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='scheduled', verbose_name="Статус")
    bus_info = models.CharField(max_length=200, verbose_name="Информация об автобусе", default='')
    driver_name = models.CharField(max_length=100, verbose_name="Имя водителя", default='')
    driver_phone = models.CharField(max_length=20, verbose_name="Телефон водителя", default='')
    is_cancelled = models.BooleanField(default=False, verbose_name="Отменен")
    cancellation_reason = models.TextField(blank=True, null=True, verbose_name="Причина отмены")

    from django.db import models
from django.contrib.auth.models import User

class Ticket(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    route = models.CharField(max_length=255)
    seat_number = models.CharField(max_length=10)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    departure_time = models.DateTimeField()
    arrival_time = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)



from django.db import models
from django.contrib.auth.models import User

class Ticket(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    route = models.ForeignKey('Route', on_delete=models.CASCADE)
    seat_number = models.CharField(max_length=10)
    purchase_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=10, choices=[('booked', 'Забронирован'), ('paid', 'Оплачен')])

    def __str__(self):
        return f"{self.route} - {self.seat_number}"
    class Meta:
        
        ordering = ['departure_time']
        verbose_name = "Маршрут"
        verbose_name_plural = "Маршруты"
        

from django.contrib.auth.models import User
from django.db import models

class Ticket(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    route = models.CharField(max_length=255)
    seat_number = models.CharField(max_length=10)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    departure_time = models.DateTimeField()
    arrival_time = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.route} - {self.seat_number}"



    def __str__(self):
        return f"{self.number} {self.from_city} - {self.to_city}"

    def update_status(self):
        now = timezone.now()
        if self.is_cancelled:
            self.status = 'cancelled'
        elif now < self.departure_time:
            self.status = 'scheduled'
        elif now >= self.departure_time and now <= self.arrival_time:
            self.status = 'on_route'
        else:
            self.status = 'completed'
        self.save()



class Route(models.Model):
    from_city = models.CharField(max_length=100)
    to_city = models.CharField(max_length=100)
    departure_time = models.DateTimeField()
    arrival_time = models.DateTimeField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    total_seats = models.IntegerField(default=48)

    def __str__(self):
        return f"{self.from_city} → {self.to_city}"

class Seat(models.Model):
    STATUS_CHOICES = [
        ('available', 'Свободно'),
        ('booked', 'Бронь'),
        ('occupied', 'Занято'),
    ]
    route = models.ForeignKey(Route, on_delete=models.CASCADE, related_name='seats')
    seat_number = models.PositiveIntegerField()
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='available')

    def __str__(self):
        return f"Место {self.seat_number} – {self.get_status_display()}"



class Ticket(models.Model):
    STATUS_CHOICES = [
        ('booked', 'Забронирован'),
        ('purchased', 'Куплен'),
        ('cancelled', 'Отменен'),
        ('refunded', 'Возвращен'),
    ]

    route = models.ForeignKey(Route, on_delete=models.CASCADE, verbose_name="Маршрут")
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="Пользователь", null=True, blank=True)
    seat_number = models.IntegerField(verbose_name="Номер места")
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='booked', verbose_name="Статус")
    booking_time = models.DateTimeField(default=timezone.now, verbose_name="Время бронирования")
    purchase_time = models.DateTimeField(null=True, blank=True, verbose_name="Время покупки")
    is_purchased = models.BooleanField(default=False, verbose_name="Оплачен")
    passenger_name = models.CharField(max_length=100, verbose_name="Имя пассажира", default='')
    passenger_phone = models.CharField(max_length=20, verbose_name="Телефон пассажира", default='')
    passenger_document = models.CharField(max_length=20, verbose_name="Документ пассажира", default='')
    refund_reason = models.TextField(blank=True, null=True, verbose_name="Причина возврата")
    refund_time = models.DateTimeField(null=True, blank=True, verbose_name="Время возврата")

    class Meta:
        unique_together = ['route', 'seat_number']
        ordering = ['route', 'seat_number']
        verbose_name = "Билет"
        verbose_name_plural = "Билеты"

    def __str__(self):
        return f"Билет {self.route} место {self.seat_number}"

    def refund(self, reason):
        if self.is_purchased and self.route.departure_time > timezone.now():
            self.status = 'refunded'
            self.refund_reason = reason
            self.refund_time = timezone.now()
            self.is_purchased = False
            self.save()
            
            # Обновляем количество свободных мест
            self.route.available_seats += 1
            self.route.save()
            
            # Создаем уведомление о возврате
            Notification.objects.create(
                user=self.user,
                ticket=self,
                type='refund',
                message=f'Билет {self.route} место {self.seat_number} успешно возвращен'
            )
            return True
        return False

class Notification(models.Model):
    TYPE_CHOICES = [
        ('status_change', 'Изменение статуса'),
        ('booking', 'Бронирование'),
        ('purchase', 'Покупка'),
        ('refund', 'Возврат'),
        ('cancellation', 'Отмена'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="Пользователь")
    ticket = models.ForeignKey(Ticket, on_delete=models.CASCADE, null=True, blank=True, verbose_name="Билет")
    type = models.CharField(max_length=20, choices=TYPE_CHOICES, verbose_name="Тип уведомления")
    message = models.TextField(verbose_name="Сообщение")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Время создания")
    is_read = models.BooleanField(default=False, verbose_name="Прочитано")

    class Meta:
        ordering = ['-created_at']
        verbose_name = "Уведомление"
        verbose_name_plural = "Уведомления"

    def __str__(self):
        return f"{self.get_type_display()} для {self.user.username}"

class BoardingList(models.Model):
    route = models.ForeignKey(Route, on_delete=models.CASCADE, verbose_name="Маршрут")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Время создания")
    updated_at = models.DateTimeField(auto_now=True, verbose_name="Время обновления")
    total_passengers = models.IntegerField(default=0, verbose_name="Всего пассажиров")
    notes = models.TextField(blank=True, null=True, verbose_name="Примечания")

    class Meta:
        ordering = ['-created_at']
        verbose_name = "Посадочная ведомость"
        verbose_name_plural = "Посадочные ведомости"

    def __str__(self):
        return f"Ведомость {self.route} от {self.created_at.strftime('%d.%m.%Y')}"

    def generate_pdf(self):
        # Здесь будет логика генерации PDF
        pass

class FavoriteRoute(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="Пользователь")
    route = models.ForeignKey(Route, on_delete=models.CASCADE, verbose_name="Маршрут")
    created_at = models.DateTimeField(auto_now_add=True, verbose_name="Добавлено в избранное")

    class Meta:
        unique_together = ['user', 'route']
        verbose_name = "Избранный маршрут"
        verbose_name_plural = "Избранные маршруты"

    def __str__(self):
        return f"{self.user.username} - {self.route}"
